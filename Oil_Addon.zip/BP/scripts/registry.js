export const FluidRegistry = {
  "lumstudio:oil": {
    "damage": 0,
    "fog": "37ed55",
    "buoyancy": 0.03,
    "boat": true,
    "burnTime": 5,
    "effect": "slowness"
  }
};